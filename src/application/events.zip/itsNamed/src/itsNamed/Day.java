/**
 * 
 */
package itsNamed;

/**
 * @author CPGau
 *
 */
public class Day {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
